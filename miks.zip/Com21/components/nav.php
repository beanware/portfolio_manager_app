<?php 
session_start(); // Start session to access session variables
include './cdn.php'; 

// Check if a user is logged in
$loggedIn = isset($_SESSION['user_id']);
?>

<body>
<div class="navbar bg-base-100">
  <div class="navbar-start">
  <?php include './components/sidebar.php';?>
    
    
  </div>
  <div class="navbar-center">
    <a class="btn btn-ghost text-xl">Com21</a>
  </div>
  <?php
if (isset($_SESSION['user_id'])) {
?>
  <div class="navbar-end">
    <a href="./maintenance_scheduler/functions/logout.php" class="btn btn-outline btn-error">Log Out</a>
  </div>
<?php
}
?>
</div>
</body>
</html>