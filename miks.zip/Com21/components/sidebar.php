<?php
include 'cdn.php';
?>
<div class="drawer">
<input id="my-drawer" type="checkbox" class="drawer-toggle" />
<div class="drawer-content">
  <!-- Page content here -->
  <label for="my-drawer" class="btn drawer-button z-50">
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="inline-block h-5 w-5 stroke-current">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
    </svg>
  </label>
</div>
<div class="drawer-side z-40">
  <label for="my-drawer" aria-label="close sidebar" class="drawer-overlay"></label>
  <ul class="menu bg-base-200 text-base-content min-h-full w-80 p-4">
    <li><a href="./index.php">Homepage</a></li>
    <?php
if (isset($_SESSION['user_id'])) {
?>
    <li><a href="./maintenance_scheduler/" >Admin Dashboard</a></li>
    <li><a href="./ticket_app/index.php" >Engineering Dashboard</a></li>
<?php } ?>
    <li><a href="./ticket_app/ticket_form.php" >Customer Support</a></li>
  </ul>
</div>
</div>