<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Path to PHPMailer autoload

if ($_POST) {
  // Retrieve form data safely
  $visitor_name = isset($_POST['visitor_name']) ? trim($_POST['visitor_name']) : '';
  $visitor_email = isset($_POST['visitor_email']) ? trim($_POST['visitor_email']) : '';
  $visitor_phone = isset($_POST['visitor_phone']) ? trim($_POST['visitor_phone']) : '';
  $total_adults = isset($_POST['total_adults']) ? (int)$_POST['total_adults'] : 0;
  $total_children = isset($_POST['total_children']) ? (int)$_POST['total_children'] : 0;
  $checkin = isset($_POST['checkin']) ? $_POST['checkin'] : '';
  $checkout = isset($_POST['checkout']) ? $_POST['checkout'] : '';
  $room_preference = isset($_POST['room_preference']) ? $_POST['room_preference'] : '';
  $visitor_message = isset($_POST['visitor_message']) ? trim($_POST['visitor_message']) : '';

  // Define recipient email
  $recipient = "your-email@example.com"; // Change this to your actual email

  // Construct email content
  $email_content = "
      <h2>Hotel Room Reservation</h2>
      <p><strong>Name:</strong> $visitor_name</p>
      <p><strong>Email:</strong> $visitor_email</p>
      <p><strong>Phone:</strong> $visitor_phone</p>
      <p><strong>Adults:</strong> $total_adults</p>
      <p><strong>Children:</strong> $total_children</p>
      <p><strong>Check-in:</strong> $checkin</p>
      <p><strong>Check-out:</strong> $checkout</p>
      <p><strong>Room Preference:</strong> $room_preference</p>
      <p><strong>Message:</strong> $visitor_message</p>
  ";

  require 'vendor/autoload.php'; // Ensure PHPMailer is properly included

  $mail = new PHPMailer(true);

  try {
      // SMTP Configuration
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com'; // Gmail SMTP
      $mail->SMTPAuth = true;
      $mail->Username = 'omukatriad@gmail.com'; // Your Gmail
      $mail->Password = 'your-app-password'; // Use an App Password, not your Gmail password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port = 587;

      // Email Content
      $mail->setFrom($visitor_email, $visitor_name);
      $mail->addAddress($recipient);
      $mail->isHTML(true);
      $mail->Subject = "Hotel Room Reservation Confirmation";
      $mail->Body = $email_content;

      $mail->send();
      echo '<p>Thank you for booking. Confirmation sent!</p>';
  } catch (Exception $e) {
      echo "<p>Mail Error: {$mail->ErrorInfo}</p>";
  }
} else {
  echo '<p>Invalid request</p>';
}

?>
<script>
    var currentDateTime = new Date();
var year = currentDateTime.getFullYear();
var month = (currentDateTime.getMonth() + 1);
var date = currentDateTime.getDate();
if(date < 10) {
  date = '0' + date;
}
if(month < 10) {
  month = '0' + month;
}
var dateTomorrow = year + "-" + month + "-" + date;
var checkinElem = document.querySelector("#checkin-date");
var checkoutElem = document.querySelector("#checkout-date");
checkinElem.setAttribute("min", dateTomorrow);
checkinElem.onchange = function () {
    checkoutElem.setAttribute("min", this.value);
}
</script>
<form action="test.php" method="post">
  <div class="elem-group">
    <label for="name">Your Name</label>
    <input type="text" id="name" name="visitor_name" placeholder="John Doe" pattern=[A-Z\sa-z]{3,20} required>
  </div>
  <div class="elem-group">
    <label for="email">Your E-mail</label>
    <input type="email" id="email" name="visitor_email" placeholder="john.doe@email.com" required>
  </div>
  <div class="elem-group">
    <label for="phone">Your Phone</label>
    <input type="tel" id="phone" name="visitor_phone" placeholder="498-348-3872" pattern=(\d{3})-?\s?(\d{3})-?\s?(\d{4}) required>
  </div>
  <hr>
  <div class="elem-group inlined">
    <label for="adult">Adults</label>
    <input type="number" id="adult" name="total_adults" placeholder="2" min="1" required>
  </div>
  <div class="elem-group inlined">
    <label for="child">Children</label>
    <input type="number" id="child" name="total_children" placeholder="2" min="0" required>
  </div>
  <div class="elem-group inlined">
    <label for="checkin-date">Check-in Date</label>
    <input type="date" id="checkin-date" name="checkin" required>
  </div>
  <div class="elem-group inlined">
    <label for="checkout-date">Check-out Date</label>
    <input type="date" id="checkout-date" name="checkout" required>
  </div>
  <div class="elem-group">
    <label for="room-selection">Select Room Preference</label>
    <select id="room-selection" name="room_preference" required>
        <option value="">Choose a Room from the List</option>
        <option value="connecting">Connecting</option>
        <option value="adjoining">Adjoining</option>
        <option value="adjacent">Adjacent</option>
    </select>
  </div>
  <hr>
  <div class="elem-group">
    <label for="message">Anything Else?</label>
    <textarea id="message" name="visitor_message" placeholder="Tell us anything else that might be important." required></textarea>
  </div>
  <button type="submit">Book The Rooms</button>
</form>