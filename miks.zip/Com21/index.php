
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <!-- Navigation -->
<?php include'./components/nav.php'?>
<!-- Navigation -->
<div
  class="hero min-h-screen"
  style="background-image: url(https://wallpaperaccess.com/full/186244.jpg);">
  <div class="hero-overlay bg-opacity-60"></div>
  <div class="hero-content text-neutral-content text-center">
    <div class="max-w-md text-gray-300">
      <h1 class="mb-5 text-5xl font-bold uppercase">Are you looking for customer support?</h1>
      <!-- <p class="mb-5">
        Are you looking for customer support?
      </p> -->
      <a href="./ticket_app/ticket_form.php" class="btn btn-primary">Create ticket</a>
    </div>
  </div>
</div>
</body>
</html>