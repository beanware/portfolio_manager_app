<?php
include 'connection.php';
include 'navbar.php';

// Fetch all projects
$query = "SELECT * FROM projects";
$result = $connection->query($query);

// Check for errors
if (!$result) {
    die("Query failed: " . $connection->error);
}

// Fetch the projects into an array
$projects = [];
while ($row = $result->fetch_assoc()) {
    $projects[] = $row;
}

// Do not close the connection here, keep it open for the images
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <h1 class="text-3xl font-bold text-center text-black mb-8 pt-10">Project Gallery</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" >
        <?php foreach ($projects as $project): ?>
                <div class="card bg-base-100 w-96 shadow-xl m-4">
                <!-- Fetch and display main image -->
                <?php
                // Get the main image for the project
                $mainImageQuery = "SELECT * FROM mainimages WHERE project_id = " . intval($project['project_id']);
                $mainImageResult = $connection->query($mainImageQuery);
                
                // Check if the main image query was successful
                if ($mainImageResult) {
                    $mainImage = $mainImageResult->fetch_assoc();
                } else {
                    $mainImage = null; // If there is no main image
                }
                ?>
            
                <?php if ($mainImage): ?>
                <figure class="px-10 pt-10">
                    <img
                  src="<?php echo htmlspecialchars($mainImage['image_path']); ?>"
                  alt="<?php echo htmlspecialchars($mainImage['image_title']); ?>"
                  class="rounded-xl" /></figure>

                <?php else: ?>
                <figure class="px-10 pt-10">
                    <img src="uploads/main/default.jpg" alt="Default image" class="rounded-xl"></figure> <!-- Default image -->
                <?php endif; ?>
            
                <div class="card-body items-center text-center">
                <h2 class="card-title"><?php echo htmlspecialchars($project['project_name']); ?></h2>
                <p><?php echo htmlspecialchars($project['project_description']); ?></p>

                <div class="card-actions">
                    <a href="project_details.php?id=<?php echo intval($project['project_id']); ?>" class="btn btn-primary">View Details</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        
    </div>


    <?php $connection->close(); // Close the connection after all queries are done ?>
    <?php include 'footer.php'; ?>
