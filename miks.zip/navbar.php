<?php
session_start(); // Start the session

include 'session.php';
// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Portfolio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- For icons -->
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/preline@2.7.0/dist/preline.min.js"></script>  
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.23/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body class="bg-gray-100 font-roboto">
    <nav class="bg-gray-700 shadow-lg">
        <div class="max-w-6xl mx-auto flex justify-between items-center p-4">
            <div class="flex items-center">
                <span style="font-family: 'Comic Sans MS', cursive; color: white; font-size: 1.125rem; font-weight: bold;">Mikaye's Gallery</span>

            </div>
            <div class="hidden md:flex space-x-4">
                <a href="index.php" class="text-gray-400 hover:text-white">Home</a>
                <a href="gallery.php" class="text-gray-400 hover:text-white">Project Gallery</a>

                <?php if ($isLoggedIn): ?>
                    <a href="projects.php" class="text-gray-400 hover:text-white">Manage Projects</a>
                <?php endif; ?>

                <a href="about.php" class="text-gray-400 hover:text-white">About</a>

                <?php if (!$isLoggedIn): ?>
                    <!--<a href="contact.php" class="text-gray-400 hover:text-white">Contact</a>-->
                    <!--    <a href="create-admin.php" class="text-red-300 hover:text-red-600">-->
                    <!--      <i class="fas fa-cog"></i>-->
                    <!--    </a>-->

                <?php else: ?>
                    <a href="logout.php" class="text-red-300 hover:text-red-600">Logout</a>
                <?php endif; ?>
            </div>
            <div class="md:hidden">
                <button id="menu-toggle" class="text-gray-400 hover:text-white focus:outline-none">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>

    <div id="mobile-menu" class="md:hidden hidden">
        <div class="flex flex-col space-y-2 p-4">
            <a href="index.php" class="text-gray-400 hover:text-white">Home</a>
            <a href="gallery.php" class="text-gray-400 hover:text-white">Project Gallery</a>

            <?php if ($isLoggedIn): ?>
                <a href="projects.php" class="text-gray-400 hover:text-white">Manage Projects</a>
            <?php endif; ?>

            <a href="about.php" class="text-gray-400 hover:text-white">About</a>

            <?php if (!$isLoggedIn): ?>
                <!--<a href="contact.php" class="text-gray-400 hover:text-white">Contact</a>-->
            <?php else: ?>
                <a href="logout.php" class="text-red-300 hover:text-red-600">Logout</a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Toggle mobile menu
        const menuToggle = document.getElementById('menu-toggle');
        const mobileMenu = document.getElementById('mobile-menu');

        menuToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    </script>

</body>
</html>
